This LaTeX template (unofficial) allows the article production of the Federal University of Technology — Paraná (UTFPR).

It was developed based on the abnTeX2 article template, available at <http://www.abntex.net.br/>, as well as several code snippets developed by TeX-LaTeX Stack Exchange users, available at <http://tex.stackexchange.com/>.

Status: added by Luiz E. M. Lima, maintenance on demand.
Last updated: December 5, 2019 (Version 1.2).

Status: adapted for the event SEI-SICITE UTFPR Guarapuava as previous article in DOC format.
Authors: Andres Jessé Porfírio (andresporfirio@utfpr.edu.br), Hermano Pereira (hermanopereira@utfpr.edu.br),  Lyvia Regina Biagi Silva Bertachi (lyviar@utfpr.edu.br), Marizete Righi Cechin (mrcechin@utfpr.edu.br), Renata Luiza Stange Carneiro Gomes (rlgomes@utfpr.edu.br), Thalita Monteiro Obal (thalitaobal@utfpr.edu.br).
Last updated: July 31, 2021.


Este modelo LaTeX (não oficial) permite a produção de artigo da Universidade Tecnológica Federal do Paraná (UTFPR).

Foi desenvolvido baseado no modelo de artigo abnTeX2, disponível em <http://www.abntex.net.br/>, bem como em diversos trechos de códigos desenvolvidos por usuários do TeX-LaTeX Stack Exchange, disponível em <http://tex.stackexchange.com/>.

Estado: adicionado por Luiz E. M. Lima, manutenção sob demanda.
Última atualização: 5 de dezembro de 2019 times(Versão 1.2).

Estado: artigo adaptado para o Evento SEI-SICITE UTFPR Guarapuava conforme artigo prévio em formato DOC
Autores: Andres Jessé Porfírio (andresporfirio@utfpr.edu.br), Hermano Pereira (hermanopereira@utfpr.edu.br),  Lyvia Regina Biagi Silva Bertachi (lyviar@utfpr.edu.br), Renata Luiza Stange Carneiro Gomes (rlgomes@utfpr.edu.br), Thalita Monteiro Obal (thalitaobal@utfpr.edu.br).
Última atualização: 31 de Julho de 2021.
